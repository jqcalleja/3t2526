<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="css\style.css">

    <title><?= $title; ?></title>
</head>
<body>
    <div class="container">
        <header class="banner">
            <h1 class="banner-content"><?= $header; ?></h1>
            <h3 class="banner-content"><?= date("F j, Y"); ?></h3>
        </header>